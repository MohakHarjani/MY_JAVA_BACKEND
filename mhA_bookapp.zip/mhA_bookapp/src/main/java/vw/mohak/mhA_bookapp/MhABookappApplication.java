package vw.mohak.mhA_bookapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MhABookappApplication {

	public static void main(String[] args) {
		SpringApplication.run(MhABookappApplication.class, args);
	}

}
